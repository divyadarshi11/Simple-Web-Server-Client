//Student Name-Divya Darshi
//Student ID-1002090905

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.net.URL;
import java.util.Scanner;

public class ClientD {
	// Initialize Instance Variables
	private static Socket socketD = null;
	final static String CRLF = "\r\n";
	private static String fileName;
	private static int port = 2022;

	// Main Method of ClientD
	public static void main(String args[]) throws Exception {
		long starttime, exittime, runtime;
		starttime = System.nanoTime();
		// Setting connection with the server
		String server_url = "http://" + "localhost" + ":" + port + "/";
		URL url = new URL(server_url);
		socketD = new Socket("localhost", port);
		System.out.println("Established connection on server with respect to clientD");

		// requesting file from the server
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the file you want to search");
		fileName = s.next();
		PrintStream pstream = new PrintStream(socketD.getOutputStream());
		pstream.println("GET" + " /" + fileName + " " + "HTTP/1.1" + CRLF);
		System.out.println("Connection received from : " + socketD.getInetAddress().getHostName());
		System.out.println("Port : " + socketD.getPort());
		System.out.println("Protocol :" + url.getProtocol());
		System.out.println("TCP No Delay : " + socketD.getTcpNoDelay());
		System.out.println("TCP No Delay : " + socketD);

		System.out.println("Timeout : " + socketD.getSoTimeout());
		System.out.println("response from server");
		// printing server response
		try {
			BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(socketD.getInputStream()));
			StringBuilder stringbuilder = new StringBuilder();
			String get_String;
			while ((get_String = bufferedreader.readLine()) != null) {
				stringbuilder.append(get_String + "\n");
			}
			bufferedreader.close();
			System.out.println(stringbuilder.toString());
			socketD.close();
			exittime = System.nanoTime();
			runtime = (exittime - starttime) / 1000000;
			// Calculation of RTT
			System.out.println("Calculation of RTT=" + (double) Math.round(runtime * 100) / 100 + " ms");

		} catch (IOException exception) {
			System.out.println(exception.getMessage());
			s.close();
		}
	}
}
