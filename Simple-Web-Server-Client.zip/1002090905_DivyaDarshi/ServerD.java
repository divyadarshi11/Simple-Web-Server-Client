//Student Name-Divya Darshi
//Student ID-1002090905

import java.io.*;
import java.net.*;
import java.util.StringTokenizer;

public final class ServerD {

	public static void main(String[] args) throws Exception {

		// Declare a TCP socket object and initialize it to null
		// ServerSocket serverSocket = null;
		// Set the port number.
		int port = 2022;
		ServerSocket ss = null;

		// Establish the listen-to the socket
		try {

			ss = new ServerSocket(port);
			System.out.println("TCP server has been created on port =" + port);


		// Process HTTP service requests in an infinite loop.
		while (true) {
			Socket clientsoc = null;

			clientsoc = ss.accept();

			// Construct an object to process the HTTP request message
			HttpRequest request = new HttpRequest(clientsoc);

			// create a new thread to process the request
			Thread thread = new Thread(request);

			// Start the thread
			thread.start();

		}
		}
		 catch (IOException exception) {
				System.out.println("Error : The server with port=" + port + "cannot be created");
			}
		// Closing the socket
		finally {
		    try {  
		    	ss.close();
		    } catch(Exception ex) {
		        // If you really want to know why you can't close the ServerSocket, like whether it's null or not
		    }
		}

	}
	
}
 final class HttpRequest implements Runnable {

	final static String CRLF = "\r\n";
	Socket socketD;

	// Passing the socket object in HTTP request Constructor
	public HttpRequest(Socket socketD) throws Exception {
		this.socketD = socketD;
	}

	@Override
	public void run() {
		try {
			processRequest();
            
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
//Process Client Request here and print the connection information 
	private void processRequest() throws Exception {
		String server_url = "http://localhost:" + socketD.getPort() + "/";
		System.out.println("server " + server_url);
		URL url = new URL(server_url);
		System.out.println("URL " + url);
		InputStream in = socketD.getInputStream();
		DataOutputStream os = new DataOutputStream(socketD.getOutputStream());
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String requestLine = br.readLine();
		System.out.println();

		// information from the connection objects,
		System.out.println("*********************************************************************************");
		System.out.println("information from the connection objects through multithreaded implementation");
		System.out.println("*********************************************************************************");
		System.out.println("RequestLine " + requestLine);

		// Client send and received a message from the server
		System.out.println("Connection received from " + socketD.getInetAddress().getHostName());
		System.out.println("Port : " + socketD.getPort());

		// Extracting and displaying all the connection parameter
		System.out.println("Protocol : " + url.getProtocol());
		System.out.println("TCP No Delay : " + socketD.getTcpNoDelay());
		System.out.println("Timeout : " + socketD.getSoTimeout());
		System.out.println("**********************************************************************************");
		System.out.println();
		String headerline = null;
		while ((headerline = br.readLine()).length() != 0) {
			System.out.println(headerline);
		}
            // Creating the StringTokenizer and passing the request line in the constructor
		//tokens object split the request line and creates the token 
		StringTokenizer tokenD = new StringTokenizer(requestLine);
            tokenD.nextToken(); 
		String fileName = tokenD.nextToken();

		// Prepend a “.” so that the file request is within the current directory.
		fileName = "." + fileName;
		System.out.println("GET FileName" + fileName);

		// Open the requested file.
		FileInputStream fis = null;
		boolean fileExist = true;
		try {
			fis = new FileInputStream(fileName);
		} catch (FileNotFoundException ex) {
			fileExist = false;
		}
		// Construct the response message.
		String linestatus = null;
		String lineContentType = null;
		String entityBody = null;

		//Check file exists in the directory or not
		if (fileExist) {
			linestatus = " line status = success ";
			lineContentType = "Content_Type:" + contentType(fileName) + CRLF;
		} else {
			linestatus = " 404 file Not Found:";
			lineContentType = "Content_Type: text/html" + CRLF;
			entityBody = "<HTML>" + "<HEAD> <TITLE> file Not Found</TITLE></HEAD>" + "<BODY> file Not Found</BODY><HTML>";
		}
		// Send the status line.
		os.writeBytes(linestatus);
		os.writeBytes(CRLF);

		// Send the content-type line.
		os.writeBytes(lineContentType);

		// Send a blank line to indicate the end of the header lines.
		os.writeBytes(CRLF);

		// Send the entity-body.
		if (fileExist) {

			sendBytes(fis, os);

			fis.close();
		} else {
			os.writeBytes(entityBody);
		}
       //close the open objects
		os.close();
		br.close();
		socketD.close();

	}
    //contentType Method which evaluates the file extension
	private static String contentType(String fileName) {
		if (fileName.endsWith(".txt")) {
			return "text";
		}
		
		return "application/octet-stream";
	}

	private static void sendBytes(FileInputStream fis, OutputStream os) throws Exception {

		// Construct a 1K buffer to hold bytes on their way to the socket.
		byte[] buffer = new byte[1024];
		int bytes = 0;

		// Copy the requested file into the socket’s output stream.
		while ((bytes = fis.read(buffer)) != -1) {
			os.write(buffer, 0, bytes);
		}

	}

}